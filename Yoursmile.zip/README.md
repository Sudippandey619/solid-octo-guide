
  # Animated Video Surprise Website

  This is a code bundle for Animated Video Surprise Website. The original project is available at https://www.figma.com/design/U2bxIRtzPGtlqT1VjvahPR/Animated-Video-Surprise-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  